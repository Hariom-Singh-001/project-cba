import { Heart, Users, Award } from 'lucide-react';
import Navbar from '../components/Navbar';
import Chatbot from '../components/Chatbot';

interface Story {
  id: number;
  title: string;
  description: string;
  impact: string;
  category: 'blood' | 'fundraising' | 'equipment';
  author: string;
  date: string;
}

export default function SuccessStories() {
  const stories: Story[] = [
    {
      id: 1,
      title: 'A Second Chance at Life',
      description:
        'Ravi needed an urgent blood transfusion after a car accident. Thanks to our blood donors, he received life-saving blood within hours. Today, he is back to his family and grateful for every moment.',
      impact: 'Saved from critical condition',
      category: 'blood',
      author: 'Ravi Menon',
      date: 'Nov 2024',
    },
    {
      id: 2,
      title: 'When Community Comes Together',
      description:
        'Anjali was fighting cancer but couldn\'t afford chemotherapy. Our community raised ₹15 lakhs through CBA crowdfunding. She completed her treatment and is now in remission. Her story inspires many.',
      impact: '₹15L raised, Life saved',
      category: 'fundraising',
      author: 'Anjali Chopra',
      date: 'Oct 2024',
    },
    {
      id: 3,
      title: 'Equipment That Changed Everything',
      description:
        'A rural health center got access to critical diagnostic equipment through our donation program. Now they can serve 500+ patients monthly. Healthcare is no longer miles away.',
      impact: '500+ patients served monthly',
      category: 'equipment',
      author: 'Dr. Sharma',
      date: 'Sep 2024',
    },
    {
      id: 4,
      title: 'From Recipient to Donor',
      description:
        'After receiving blood that saved his life, Vikram became a regular blood donor. He has now donated 20 times and helped save approximately 60 lives. His gratitude turned into action.',
      impact: '60+ lives potentially saved',
      category: 'blood',
      author: 'Vikram Kumar',
      date: 'Aug 2024',
    },
    {
      id: 5,
      title: 'Baby Arjun\'s Recovery',
      description:
        'Little Arjun was born premature and needed immediate medical care costing ₹8 lakhs. The CBA community came together, and within days, the funds were raised. Arjun is now a healthy 2-year-old.',
      impact: '₹8L raised for medical care',
      category: 'fundraising',
      author: 'Arjun\'s Parents',
      date: 'Jul 2024',
    },
    {
      id: 6,
      title: 'Dialysis Center Opens',
      description:
        'Through our equipment donation program, a community dialysis center was established. 50 kidney patients now have affordable access to treatment. Hope restored for entire families.',
      impact: '50 patients now have access to dialysis',
      category: 'equipment',
      author: 'NGO Partners',
      date: 'Jun 2024',
    },
  ];

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'blood':
        return 'from-red-500 to-red-600';
      case 'fundraising':
        return 'from-green-500 to-green-600';
      case 'equipment':
        return 'from-blue-500 to-blue-600';
      default:
        return 'from-gray-500 to-gray-600';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'blood':
        return <Heart className="w-5 h-5" />;
      case 'fundraising':
        return <Users className="w-5 h-5" />;
      case 'equipment':
        return <Award className="w-5 h-5" />;
      default:
        return <Award className="w-5 h-5" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 relative overflow-hidden">
      <div className="fixed inset-0 z-0">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover opacity-15"
        >
          <source
            src="https://cdn.coverr.co/videos/coverr-medical-team-in-hospital-4468/1080p.mp4"
            type="video/mp4"
          />
        </video>
        <div className="absolute inset-0 bg-gradient-to-br from-gray-950/95 via-gray-900/95 to-gray-950/95"></div>
      </div>

      <div className="relative z-10">
        <Navbar currentPage="stories" />

        <div className="pt-24 pb-20 px-6">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-16">
              <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">
                Success <span className="text-red-500">Stories</span>
              </h1>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto">
                Real stories of hope, courage, and community. Read how CBA is transforming lives every single day.
              </p>
            </div>

            <div className="grid gap-6 mb-12">
              {stories.map((story) => (
                <div
                  key={story.id}
                  className="bg-gray-800/50 backdrop-blur border border-gray-700/50 rounded-2xl overflow-hidden hover:border-red-500/30 transition-all group"
                >
                  <div className="p-8">
                    <div className="flex items-start space-x-4">
                      <div
                        className={`bg-gradient-to-br ${getCategoryColor(story.category)} p-3 rounded-xl flex-shrink-0`}
                      >
                        <div className="text-white">{getCategoryIcon(story.category)}</div>
                      </div>

                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h3 className="text-2xl font-bold text-white group-hover:text-red-400 transition-colors">
                              {story.title}
                            </h3>
                            <div className="flex items-center space-x-3 mt-2 text-sm text-gray-400">
                              <span>{story.author}</span>
                              <span>•</span>
                              <span>{story.date}</span>
                            </div>
                          </div>
                        </div>

                        <p className="text-gray-300 mb-4 leading-relaxed">{story.description}</p>

                        <div className="bg-gray-900/50 border border-gray-700/50 rounded-lg p-4 inline-block">
                          <p className="text-sm text-gray-400 mb-1">Impact</p>
                          <p className="text-red-400 font-semibold">{story.impact}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-gradient-to-r from-red-600/20 to-rose-600/20 border border-red-500/30 rounded-2xl p-8 text-center">
              <h3 className="text-2xl font-bold text-white mb-3">Your Story Matters</h3>
              <p className="text-gray-300 mb-6">
                Have a success story to share? We'd love to hear how CBA made a difference in your life or someone you know.
              </p>
              <button className="bg-gradient-to-r from-red-500 to-rose-600 text-white px-8 py-3 rounded-full font-bold hover:shadow-lg hover:scale-105 transition-all">
                Share Your Story
              </button>
            </div>

            <div className="mt-12 grid md:grid-cols-3 gap-6">
              <div className="bg-gray-800/50 backdrop-blur border border-gray-700/50 rounded-xl p-6 text-center">
                <div className="text-4xl font-bold text-red-400 mb-2">2000+</div>
                <p className="text-gray-300">Lives Saved</p>
              </div>
              <div className="bg-gray-800/50 backdrop-blur border border-gray-700/50 rounded-xl p-6 text-center">
                <div className="text-4xl font-bold text-green-400 mb-2">₹5Cr+</div>
                <p className="text-gray-300">Funds Raised</p>
              </div>
              <div className="bg-gray-800/50 backdrop-blur border border-gray-700/50 rounded-xl p-6 text-center">
                <div className="text-4xl font-bold text-blue-400 mb-2">500+</div>
                <p className="text-gray-300">Communities Served</p>
              </div>
            </div>
          </div>
        </div>

        <Chatbot />
      </div>
    </div>
  );
}
