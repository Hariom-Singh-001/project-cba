import { Trophy, Droplet, TrendingUp, Medal } from 'lucide-react';
import Navbar from '../components/Navbar';
import Chatbot from '../components/Chatbot';

interface LeaderboardEntry {
  rank: number;
  name: string;
  donated: number;
  raised: number;
  impact: string;
  badge: 'gold' | 'silver' | 'bronze' | 'none';
}

export default function Leaderboard() {
  const topDonors: LeaderboardEntry[] = [
    { rank: 1, name: 'Rajesh Kumar', donated: 45, raised: 0, impact: 'Blood Donor Hero', badge: 'gold' },
    { rank: 2, name: 'Priya Sharma', donated: 38, raised: 0, impact: 'Lifesaver', badge: 'silver' },
    { rank: 3, name: 'Amir Khan', donated: 32, raised: 0, impact: 'Dedicated Donor', badge: 'bronze' },
    { rank: 4, name: 'Neha Verma', donated: 28, raised: 0, impact: 'Caring Heart', badge: 'none' },
    { rank: 5, name: 'Vikram Patel', donated: 25, raised: 0, impact: 'Community Leader', badge: 'none' },
  ];

  const topFundraisers: LeaderboardEntry[] = [
    { rank: 1, name: 'Sarah Johnson', donated: 0, raised: 850000, impact: 'Fundraising Champion', badge: 'gold' },
    { rank: 2, name: 'Amit Desai', donated: 0, raised: 725000, impact: 'Hope Builder', badge: 'silver' },
    { rank: 3, name: 'Emma Williams', donated: 0, raised: 620000, impact: 'Community Advocate', badge: 'bronze' },
    { rank: 4, name: 'Rohan Singh', donated: 0, raised: 545000, impact: 'Making Waves', badge: 'none' },
    { rank: 5, name: 'Lisa Chen', donated: 0, raised: 480000, impact: 'Helping Hands', badge: 'none' },
  ];

  const getBadgeColor = (badge: string) => {
    switch (badge) {
      case 'gold':
        return 'from-yellow-400 to-yellow-600';
      case 'silver':
        return 'from-gray-300 to-gray-500';
      case 'bronze':
        return 'from-orange-400 to-orange-600';
      default:
        return 'from-blue-400 to-blue-600';
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 relative overflow-hidden">
      <div className="fixed inset-0 z-0">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover opacity-15"
        >
          <source
            src="https://cdn.coverr.co/videos/coverr-medical-team-in-hospital-4468/1080p.mp4"
            type="video/mp4"
          />
        </video>
        <div className="absolute inset-0 bg-gradient-to-br from-gray-950/95 via-gray-900/95 to-gray-950/95"></div>
      </div>

      <div className="relative z-10">
        <Navbar currentPage="leaderboard" />

        <div className="pt-24 pb-20 px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">
                Hall of <span className="text-red-500">Heroes</span>
              </h1>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto">
                Celebrating the amazing individuals making a difference in healthcare and saving lives every day.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <div className="flex items-center space-x-3 mb-6">
                  <div className="bg-red-500/20 p-3 rounded-xl">
                    <Droplet className="w-6 h-6 text-red-400" />
                  </div>
                  <h2 className="text-2xl font-bold text-white">Top Blood Donors</h2>
                </div>

                <div className="space-y-4">
                  {topDonors.map((donor) => (
                    <div
                      key={donor.rank}
                      className="bg-gray-800/50 backdrop-blur border border-red-900/30 rounded-xl p-4 hover:border-red-500/50 transition-all hover:scale-105"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center justify-center w-12 h-12 bg-gray-700 rounded-lg font-bold text-lg">
                          {donor.rank === 1 && <span className="text-yellow-400">🥇</span>}
                          {donor.rank === 2 && <span className="text-gray-300">🥈</span>}
                          {donor.rank === 3 && <span className="text-orange-400">🥉</span>}
                          {donor.rank > 3 && <span className="text-white">{donor.rank}</span>}
                        </div>

                        <div className="flex-1">
                          <h3 className="text-white font-bold text-lg">{donor.name}</h3>
                          <p className="text-gray-400 text-sm">{donor.impact}</p>
                          <div className="mt-2 flex items-center space-x-2">
                            <Droplet className="w-4 h-4 text-red-400" />
                            <span className="text-red-400 font-semibold">{donor.donated} donations</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center space-x-3 mb-6">
                  <div className="bg-rose-500/20 p-3 rounded-xl">
                    <TrendingUp className="w-6 h-6 text-rose-400" />
                  </div>
                  <h2 className="text-2xl font-bold text-white">Top Fundraisers</h2>
                </div>

                <div className="space-y-4">
                  {topFundraisers.map((raiser) => (
                    <div
                      key={raiser.rank}
                      className="bg-gray-800/50 backdrop-blur border border-rose-900/30 rounded-xl p-4 hover:border-rose-500/50 transition-all hover:scale-105"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center justify-center w-12 h-12 bg-gray-700 rounded-lg font-bold text-lg">
                          {raiser.rank === 1 && <span className="text-yellow-400">🥇</span>}
                          {raiser.rank === 2 && <span className="text-gray-300">🥈</span>}
                          {raiser.rank === 3 && <span className="text-orange-400">🥉</span>}
                          {raiser.rank > 3 && <span className="text-white">{raiser.rank}</span>}
                        </div>

                        <div className="flex-1">
                          <h3 className="text-white font-bold text-lg">{raiser.name}</h3>
                          <p className="text-gray-400 text-sm">{raiser.impact}</p>
                          <div className="mt-2 flex items-center space-x-2">
                            <TrendingUp className="w-4 h-4 text-green-400" />
                            <span className="text-green-400 font-semibold">₹{(raiser.raised / 100000).toFixed(1)}L raised</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-16 bg-gradient-to-r from-red-600/20 to-rose-600/20 border border-red-500/30 rounded-2xl p-8 text-center">
              <Trophy className="w-12 h-12 text-yellow-400 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-white mb-2">Be the Next Hero</h3>
              <p className="text-gray-300 mb-6">
                Join our community of heroes and make a difference. Every donation counts!
              </p>
              <button className="bg-gradient-to-r from-red-500 to-rose-600 text-white px-8 py-3 rounded-full font-bold hover:shadow-lg hover:scale-105 transition-all">
                Start Contributing
              </button>
            </div>
          </div>
        </div>

        <Chatbot />
      </div>
    </div>
  );
}
