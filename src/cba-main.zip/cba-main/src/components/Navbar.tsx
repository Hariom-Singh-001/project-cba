import { Home, User, Trophy, BookOpen, Menu, X } from 'lucide-react';
import { useState } from 'react';

interface NavbarProps {
  currentPage?: string;
}

export default function Navbar({ currentPage = 'home' }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isHomePage = currentPage === 'home';
  const bgClass = isHomePage ? 'bg-white/80' : 'bg-gray-950/80';
  const textClass = isHomePage ? 'text-gray-700' : 'text-gray-200';
  const hoverClass = isHomePage ? 'hover:text-red-600' : 'hover:text-red-400';

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 ${bgClass} backdrop-blur-md border-b border-red-900/20 shadow-sm transition-all`}>
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <a href="/" className="flex items-center space-x-3">
            <div className="bg-gradient-to-br from-red-500 to-rose-600 p-2.5 rounded-xl shadow-lg">
              <svg
                className="w-8 h-8 text-white"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M20.42 4.58a5.4 5.4 0 0 0-7.65 0l-.77.78-.77-.78a5.4 5.4 0 0 0-7.65 0C1.46 6.7 1.33 10.28 4 13l8 8 8-8c2.67-2.72 2.54-6.3.42-8.42z" />
                <path d="M12 5v14M5 12h14" />
              </svg>
            </div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-red-600 to-rose-500 bg-clip-text text-transparent">
              CBA
            </h1>
          </a>

          <div className="hidden md:flex items-center space-x-8">
            <a
              href="/"
              className={`flex items-center space-x-2 ${textClass} ${hoverClass} transition-colors group`}
            >
              <Home className="w-4 h-4 group-hover:scale-110 transition-transform" />
              <span className="font-medium">Home</span>
            </a>
            <a
              href="/leaderboard"
              className={`flex items-center space-x-2 ${textClass} ${hoverClass} transition-colors group`}
            >
              <Trophy className="w-4 h-4 group-hover:scale-110 transition-transform" />
              <span className="font-medium">Leaderboard</span>
            </a>
            <a
              href="/success-stories"
              className={`flex items-center space-x-2 ${textClass} ${hoverClass} transition-colors group`}
            >
              <BookOpen className="w-4 h-4 group-hover:scale-110 transition-transform" />
              <span className="font-medium">Success Stories</span>
            </a>
          </div>

          <div className="flex items-center space-x-4">
            <button className="flex items-center space-x-2 bg-gradient-to-r from-red-500 to-rose-600 text-white px-5 py-2.5 rounded-full hover:shadow-lg hover:scale-105 transition-all">
              <User className="w-4 h-4" />
              <span className="font-medium hidden sm:inline">Profile</span>
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden text-2xl p-2"
            >
              {mobileMenuOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className={`md:hidden mt-4 space-y-3 pb-4 border-t transition-all ${isHomePage ? 'border-red-100' : 'border-red-900/20'} pt-4`}>
            <a href="/" className={`block ${textClass} font-medium hover:text-red-500`}>Home</a>
            <a href="/leaderboard" className={`block ${textClass} font-medium hover:text-red-500`}>Leaderboard</a>
            <a href="/success-stories" className={`block ${textClass} font-medium hover:text-red-500`}>Success Stories</a>
          </div>
        )}
      </div>
    </nav>
  );
}
