import { ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="pt-32 pb-20 px-6">
      <div className="max-w-7xl mx-auto text-center">
        <div className="inline-block mb-6">
          <span className="bg-red-100 text-red-700 px-4 py-2 rounded-full text-sm font-semibold">
            Save Lives • Build Hope • Transform Communities
          </span>
        </div>

        <h1 className="text-6xl md:text-7xl font-bold mb-6 leading-tight">
          <span className="bg-gradient-to-r from-red-600 via-rose-500 to-red-600 bg-clip-text text-transparent">
            Every Drop Counts
          </span>
          <br />
          <span className="text-gray-800">Every Donation Matters</span>
        </h1>

        <p className="text-xl text-gray-600 mb-12 max-w-3xl mx-auto leading-relaxed">
          Join CBA in revolutionizing healthcare accessibility through crowdfunding and blood
          management. Together, we can bridge the gap between those who need care and those who can
          provide it.
        </p>

        <button className="group bg-gradient-to-r from-red-600 to-rose-600 text-white px-8 py-4 rounded-full text-lg font-semibold hover:shadow-2xl hover:scale-105 transition-all inline-flex items-center space-x-2">
          <span>Start Making a Difference</span>
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </button>

        <div className="mt-16 grid grid-cols-3 gap-8 max-w-3xl mx-auto">
          <div className="text-center">
            <div className="text-4xl font-bold text-red-600 mb-2">50K+</div>
            <div className="text-gray-600">Lives Saved</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-red-600 mb-2">₹10M+</div>
            <div className="text-gray-600">Funds Raised</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-red-600 mb-2">200+</div>
            <div className="text-gray-600">Active Campaigns</div>
          </div>
        </div>
      </div>
    </section>
  );
}
