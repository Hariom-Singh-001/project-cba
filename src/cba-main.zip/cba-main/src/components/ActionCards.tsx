import { Heart, TrendingUp, Package, ArrowRight } from 'lucide-react';

export default function ActionCards() {
  const cards = [
    {
      icon: Heart,
      title: 'Donate Blood',
      description: 'Be a hero. Your blood donation can save up to three lives. Find blood drives near you.',
      color: 'from-red-500 to-rose-600',
      link: '/donate',
    },
    {
      icon: TrendingUp,
      title: 'Raise Funds',
      description: 'Start a campaign for medical expenses. Get support from a caring community.',
      color: 'from-rose-500 to-pink-600',
      link: '/raise-fund',
    },
    {
      icon: Package,
      title: 'Medical Equipment',
      description: 'Access affordable medical equipment. Rent, buy, or donate essential healthcare supplies.',
      color: 'from-pink-500 to-red-600',
      link: '/medical-equipment',
    },
  ];

  return (
    <section className="py-16 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-3 gap-8">
          {cards.map((card, index) => {
            const Icon = card.icon;
            return (
              <a
                key={index}
                href={card.link}
                className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border border-red-100 hover:border-red-300 hover:-translate-y-2"
              >
                <div
                  className={`bg-gradient-to-br ${card.color} w-16 h-16 rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}
                >
                  <Icon className="w-8 h-8 text-white" />
                </div>

                <h3 className="text-2xl font-bold text-gray-800 mb-3">{card.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{card.description}</p>

                <div className="flex items-center text-red-600 font-semibold group-hover:translate-x-2 transition-transform">
                  <span>Get Started</span>
                  <ArrowRight className="w-5 h-5 ml-2" />
                </div>
              </a>
            );
          })}
        </div>
      </div>
    </section>
  );
}
