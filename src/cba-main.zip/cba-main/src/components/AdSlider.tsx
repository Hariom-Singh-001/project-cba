import { X } from 'lucide-react';
import { useState } from 'react';

export default function AdSlider() {
  const [isVisible, setIsVisible] = useState(true);

  const ads = [
    {
      title: 'Blood Drive',
      date: 'Nov 15',
      location: 'City Hospital',
      color: 'from-red-500 to-rose-600',
    },
    {
      title: 'Free Health Camp',
      date: 'Nov 20',
      location: 'Community Center',
      color: 'from-rose-500 to-pink-600',
    },
    {
      title: 'Equipment Donation',
      date: 'Nov 25',
      location: 'Medical College',
      color: 'from-pink-500 to-red-600',
    },
  ];

  if (!isVisible) return null;

  return (
    <div className="fixed left-6 top-1/2 -translate-y-1/2 z-40 hidden lg:block">
      <div className="bg-white rounded-2xl shadow-2xl p-4 w-64 border border-red-100">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold text-gray-800">Upcoming Events</h3>
          <button
            onClick={() => setIsVisible(false)}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-3">
          {ads.map((ad, index) => (
            <div
              key={index}
              className={`bg-gradient-to-br ${ad.color} rounded-xl p-4 text-white transform hover:scale-105 transition-transform cursor-pointer`}
            >
              <div className="text-xs opacity-90 mb-1">{ad.date}</div>
              <div className="font-bold text-sm mb-1">{ad.title}</div>
              <div className="text-xs opacity-90">{ad.location}</div>
            </div>
          ))}
        </div>

        <button className="w-full mt-4 bg-gray-100 text-gray-700 py-2 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors">
          View All Events
        </button>
      </div>
    </div>
  );
}
