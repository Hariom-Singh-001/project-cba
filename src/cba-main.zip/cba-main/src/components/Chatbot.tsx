import { useState, useRef, useEffect } from 'react';
import { Send, X, MessageCircle } from 'lucide-react';

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Array<{ type: 'user' | 'bot'; text: string }>>([
    { type: 'bot', text: 'Hi! How can CBA help you today?' },
  ]);
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const botResponses: { [key: string]: string } = {
    donate: 'You can donate blood at any of our partner hospitals or mobile blood drives. Are you interested in finding a location near you?',
    blood: 'Blood donation is a life-saving gesture. You can donate once every 3 months. Is there anything specific about blood donation you want to know?',
    fund: 'Our crowdfunding platform helps patients raise money for medical expenses. Would you like to start a campaign or contribute to an existing one?',
    equipment: 'We provide access to affordable medical equipment. You can rent, buy, or donate equipment. What are you looking for?',
    leaderboard: 'Our leaderboard shows the top donors and fundraisers. Check it out to see who is making the most impact!',
    stories: 'Success Stories showcase how our platform has changed lives. Visit the page to read inspiring stories from our community.',
    help: 'I can help you with information about donations, fundraising, medical equipment, and more. What would you like to know?',
    hi: 'Hello! Welcome to CBA. How can I assist you today?',
    hello: 'Hello! Welcome to CBA. How can I assist you today?',
  };

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessage = inputValue;
    setMessages((prev) => [...prev, { type: 'user', text: userMessage }]);
    setInputValue('');

    const lowerInput = userMessage.toLowerCase();
    let botResponse = 'Thank you for your interest! How else can I help?';

    for (const [key, value] of Object.entries(botResponses)) {
      if (lowerInput.includes(key)) {
        botResponse = value;
        break;
      }
    }

    setTimeout(() => {
      setMessages((prev) => [...prev, { type: 'bot', text: botResponse }]);
    }, 500);
  };

  return (
    <div className="fixed bottom-6 right-6 z-40">
      {isOpen ? (
        <div className="bg-white rounded-2xl shadow-2xl w-80 h-96 flex flex-col border border-red-200">
          <div className="bg-gradient-to-r from-red-500 to-rose-600 text-white p-4 rounded-t-2xl flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <MessageCircle className="w-5 h-5" />
              <h3 className="font-bold">CBA Assistant</h3>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="hover:bg-white/20 p-1 rounded transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs px-4 py-2 rounded-lg ${
                    msg.type === 'user'
                      ? 'bg-red-500 text-white rounded-br-none'
                      : 'bg-gray-100 text-gray-800 rounded-bl-none'
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <div className="border-t border-gray-200 p-4 flex gap-2">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Type a message..."
              className="flex-1 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:border-red-500 text-sm"
            />
            <button
              onClick={handleSendMessage}
              className="bg-red-500 text-white p-2 rounded-lg hover:bg-red-600 transition-colors"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setIsOpen(true)}
          className="bg-gradient-to-r from-red-500 to-rose-600 text-white p-4 rounded-full shadow-lg hover:shadow-xl hover:scale-110 transition-all"
        >
          <MessageCircle className="w-6 h-6" />
        </button>
      )}
    </div>
  );
}
