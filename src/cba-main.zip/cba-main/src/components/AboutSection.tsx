import { Target, Eye, Award } from 'lucide-react';

export default function AboutSection() {
  return (
    <section id="about" className="py-20 px-6 bg-white/50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-bold text-gray-800 mb-4">
            About <span className="text-red-600">CBA</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Care Beyond All is more than a platform—it's a movement to make healthcare accessible to
            everyone, everywhere.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-red-100">
            <div className="bg-red-100 w-14 h-14 rounded-xl flex items-center justify-center mb-4">
              <Target className="w-7 h-7 text-red-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-3">Our Mission</h3>
            <p className="text-gray-600 leading-relaxed">
              To bridge the healthcare gap by connecting donors, patients, and medical resources
              through technology and compassion.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg border border-red-100">
            <div className="bg-rose-100 w-14 h-14 rounded-xl flex items-center justify-center mb-4">
              <Eye className="w-7 h-7 text-rose-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-3">Our Vision</h3>
            <p className="text-gray-600 leading-relaxed">
              A world where no one suffers due to lack of access to blood, funds, or medical equipment.
              Healthcare is a right, not a privilege.
            </p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg border border-red-100">
            <div className="bg-pink-100 w-14 h-14 rounded-xl flex items-center justify-center mb-4">
              <Award className="w-7 h-7 text-pink-600" />
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-3">Our Impact</h3>
            <p className="text-gray-600 leading-relaxed">
              Over 50,000 lives touched, ₹10M+ raised, and countless families given hope through our
              community-driven approach.
            </p>
          </div>
        </div>

        <div className="bg-gradient-to-br from-red-600 to-rose-600 rounded-3xl p-12 text-white text-center">
          <h3 className="text-3xl font-bold mb-4">Join Our Community of Heroes</h3>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Whether you donate blood, contribute funds, or share equipment—you're making a real
            difference in someone's life today.
          </p>
          <button className="bg-white text-red-600 px-8 py-4 rounded-full font-bold text-lg hover:scale-105 transition-transform shadow-lg">
            Become a Member
          </button>
        </div>
      </div>
    </section>
  );
}
