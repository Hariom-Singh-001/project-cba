import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ActionCards from './components/ActionCards';
import AdSlider from './components/AdSlider';
import AboutSection from './components/AboutSection';
import Leaderboard from './pages/Leaderboard';
import SuccessStories from './pages/SuccessStories';
import Chatbot from './components/Chatbot';

function App() {
  const [currentPage, setCurrentPage] = useState('home');

  useEffect(() => {
    const path = window.location.pathname;
    if (path === '/leaderboard') {
      setCurrentPage('leaderboard');
    } else if (path === '/success-stories') {
      setCurrentPage('success-stories');
    } else {
      setCurrentPage('home');
    }

    const handlePopState = () => {
      const newPath = window.location.pathname;
      if (newPath === '/leaderboard') {
        setCurrentPage('leaderboard');
      } else if (newPath === '/success-stories') {
        setCurrentPage('success-stories');
      } else {
        setCurrentPage('home');
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
    if (page === 'home') {
      window.history.pushState({}, '', '/');
    } else if (page === 'leaderboard') {
      window.history.pushState({}, '', '/leaderboard');
    } else if (page === 'success-stories') {
      window.history.pushState({}, '', '/success-stories');
    }
  };

  if (currentPage === 'leaderboard') {
    return (
      <>
        <Leaderboard />
        <Chatbot />
      </>
    );
  }

  if (currentPage === 'success-stories') {
    return (
      <>
        <SuccessStories />
        <Chatbot />
      </>
    );
  }

  return (
    <>
      <div className="min-h-screen bg-white relative overflow-hidden">
        <div className="fixed inset-0 z-0">
          <video
            autoPlay
            loop
            muted
            playsInline
            className="w-full h-full object-cover opacity-20"
          >
            <source
              src="https://cdn.coverr.co/videos/coverr-medical-team-in-hospital-4468/1080p.mp4"
              type="video/mp4"
            />
          </video>
          <div className="absolute inset-0 bg-gradient-to-br from-rose-50/90 via-white/95 to-red-50/90"></div>
        </div>

        <div className="relative z-10">
          <Navbar currentPage="home" />
          <AdSlider />
          <Hero />
          <ActionCards />
          <AboutSection />
        </div>
      </div>
      <Chatbot />
    </>
  );
}

export default App;
